
  # Women’s Safety Website Prototype

  This is a code bundle for Women’s Safety Website Prototype. The original project is available at https://www.figma.com/design/BGpebl6BeUpuytxpm5hn7X/Women%E2%80%99s-Safety-Website-Prototype.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  